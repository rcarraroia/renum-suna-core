"""
Pacote de API para a Plataforma Renum.

Este pacote contém os endpoints REST e os esquemas de dados da API.
"""

from app.api.routes import rag_router

__all__ = ["rag_router"]