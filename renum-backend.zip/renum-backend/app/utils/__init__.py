"""
Pacote de utilitários para a aplicação Renum Backend.
"""