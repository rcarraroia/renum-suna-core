"""
Pacote principal da aplicação Renum Backend.
"""