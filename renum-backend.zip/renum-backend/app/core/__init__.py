"""
Módulo core da aplicação Renum Backend.
"""