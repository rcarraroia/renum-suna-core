"""
Tests for the RAG module.

This package contains tests for the RAG module.
"""