"""
Serviço para resiliência de WebSocket.

Este módulo implementa o serviço para resiliência de WebSocket, incluindo
armazenamento temporário de mensagens não entregues, detecção de conexões zumbi
e limitação de taxa.
"""

import logging
import json
import asyncio
import time
from typing import Dict, List, Set, Any, Optional, Union
from datetime import datetime, timedelta
import redis.asyncio as redis
from uuid import UUID, uuid4

from app.core.logger import logger
from app.models.websocket_models import WebSocketMessage, WebSocketMessageType
from app.repositories.websocket_repository import WebSocketRepository


class RateLimiter:
    """Limitador de taxa para WebSocket."""
    
    def __init__(self, max_requests: int, time_window: float):
        """
        Inicializa o limitador de taxa.
        
        Args:
            max_requests: Número máximo de requisições permitidas
            time_window: Janela de tempo em segundos
        """
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests: Dict[str, List[float]] = {}
    
    def is_allowed(self, key: str) -> bool:
        """
        Verifica se uma requisição é permitida.
        
        Args:
            key: Chave para identificar o cliente
            
        Returns:
            True se a requisição é permitida, False caso contrário
        """
        now = time.time()
        
        # Inicializa a lista de requisições se necessário
        if key not in self.requests:
            self.requests[key] = []
        
        # Remove requisições antigas
        self.requests[key] = [req_time for req_time in self.requests[key] if now - req_time <= self.time_window]
        
        # Verifica se o limite foi atingido
        if len(self.requests[key]) >= self.max_requests:
            return False
        
        # Adiciona a requisição atual
        self.requests[key].append(now)
        return True
    
    def get_remaining(self, key: str) -> int:
        """
        Obtém o número de requisições restantes.
        
        Args:
            key: Chave para identificar o cliente
            
        Returns:
            Número de requisições restantes
        """
        now = time.time()
        
        # Inicializa a lista de requisições se necessário
        if key not in self.requests:
            return self.max_requests
        
        # Remove requisições antigas
        self.requests[key] = [req_time for req_time in self.requests[key] if now - req_time <= self.time_window]
        
        # Retorna o número de requisições restantes
        return max(0, self.max_requests - len(self.requests[key]))
    
    def get_reset_time(self, key: str) -> float:
        """
        Obtém o tempo restante para resetar o limite.
        
        Args:
            key: Chave para identificar o cliente
            
        Returns:
            Tempo restante em segundos
        """
        now = time.time()
        
        # Inicializa a lista de requisições se necessário
        if key not in self.requests or not self.requests[key]: