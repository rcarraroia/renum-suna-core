"""
Gerenciador de conexões WebSocket para comunicação em tempo real.

Este módulo implementa o gerenciador de conexões WebSocket para comunicação
em tempo real entre o backend e o frontend, incluindo monitoramento de execuções,
notificações e atualizações de sistema.
"""

import logging
import json
import asyncio
from typing import Dict, Set, Any, Optional, List, Callable, Awaitable, Union
from uuid import UUID, uuid4
from fastapi import WebSocket, WebSocketDisconnect
from datetime import datetime
import redis.asyncio as redis

from app.core.logger import logger
from app.models.websocket_models import (
    WebSocketConnection,
    WebSocketConnectionStatus,
    WebSocketNotification,
    WebSocketStats
)


class WebSocketManager:
    """Gerenciador de conexões WebSocket."""
    
    def __init__(self, redis_client: Optional[redis.Redis] = None):
        """
        Inicializa o gerenciador de conexões WebSocket.
        
        Args:
            redis_client: Cliente Redis para PubSub (opcional)
        """
        # Dicionário de conexões ativas por canal
        self.active_connections: Dict[str, Set[WebSocket]] = {}
        
        # Dicionário de conexões por usuário
        self.user_connections: Dict[str, Set[WebSocket]] = {}
        
        # Dicionário de metadados de conexão
        self.connection_metadata: Dict[WebSocket, Dict[str, Any]] = {}
        
        # Mapeamento de WebSocket para connection_id
        self.websocket_to_connection_id: Dict[WebSocket, str] = {}
        
        # Cliente Redis para PubSub
        self.redis = redis_client
        
        # Prefixos de canais
        self.execution_channel_prefix = "ws:execution:"
        self.notification_channel_prefix = "ws:notification:"
        self.broadcast_channel = "ws:broadcast"
        self.user_channel_prefix = "ws:user:"
        
        # Tarefas de assinatura Redis PubSub
        self.pubsub_tasks: Dict[str, asyncio.Task] = {}
        
        # Heartbeat
        self.heartbeat_interval = 30  # segundos
        self.heartbeat_tasks: Dict[WebSocket, asyncio.Task] = {}
        
        # Tarefa de limpeza de conexões ociosas
        self.cleanup_task: Optional[asyncio.Task] = None
        self.cleanup_interval = 60  # segundos
        self.idle_timeout = 30  # minutos
        
        # Repositório WebSocket (será definido posteriormente)
        self.repository = None
        
        logger.info("WebSocket Manager initialized")
    
    async def connect(
        self,
        websocket: WebSocket,
        user_id: str,
        client_info: Optional[Dict[str, Any]] = None,
        resilience_service = None
    ):
        """
        Conecta um cliente WebSocket.
        
        Args:
            websocket: Conexão WebSocket
            user_id: ID do usuário
            client_info: Informações do cliente (opcional)
            resilience_service: Serviço de resiliência (opcional)
        """
        # Verifica limites de taxa se o serviço de resiliência estiver disponível
        if resilience_service:
            ip = client_info.get("ip", "unknown") if client_info else "unknown"
            rate_limit_result = await resilience_service.check_rate_limit(user_id, ip)
            
            if not rate_limit_result["allowed"]:
                # Rejeita a conexão se o limite de taxa foi excedido
                await websocket.close(code=1008, reason="Rate limit exceeded")
                
                logger.warning(
                    f"WebSocket connection rejected for user {user_id} due to rate limit: "
                    f"{rate_limit_result}"
                )
                return
        
        try:
            # Aceita a conexão
            await websocket.accept()
            
            # Gera um ID único para a conexão
            connection_id = str(uuid4())
            
            # Armazena metadados da conexão
            self.connection_metadata[websocket] = {
                "connection_id": connection_id,
                "user_id": user_id,
                "connected_at": datetime.now().isoformat(),
                "last_activity": datetime.now().isoformat(),
                "client_info": client_info or {},
                "subscribed_channels": []
            }
            
            # Mapeia WebSocket para connection_id
            self.websocket_to_connection_id[websocket] = connection_id
            
            # Adiciona à lista de conexões do usuário
            if user_id not in self.user_connections:
                self.user_connections[user_id] = set()
            
            self.user_connections[user_id].add(websocket)
            
            # Inicia heartbeat
            self.heartbeat_tasks[websocket] = asyncio.create_task(
                self._heartbeat_loop(websocket)
            )
            
            # Registra a conexão no repositório
            if self.repository:
                connection = WebSocketConnection(
                    connection_id=connection_id,
                    user_id=user_id,
                    status=WebSocketConnectionStatus.CONNECTED,
                    connected_at=datetime.now(),
                    last_activity=datetime.now(),
                    subscribed_channels=[],
                    client_info=client_info or {}
                )
                await self.repository.save_connection(connection)
            
            # Inicia a tarefa de limpeza se ainda não estiver em execução
            if self.repository and not self.cleanup_task:
                self.cleanup_task = asyncio.create_task(self._cleanup_loop())
            
            # Envia mensagens armazenadas no buffer se o serviço de resiliência estiver disponível
            if resilience_service:
                buffered_messages = await resilience_service.get_buffered_messages(user_id)
                
                if buffered_messages:
                    logger.info(f"Sending {len(buffered_messages)} buffered messages to user {user_id}")
                    
                    for message in buffered_messages:
                        try:
                            await websocket.send_json(message)
                        except Exception as e:
                            logger.error(f"Error sending buffered message: {str(e)}")
                    
                    # Limpa as mensagens do buffer
                    await resilience_service.clear_buffered_messages(user_id)
                    
                # Registra sucesso no circuit breaker
                resilience_service.record_success(user_id)
            
            logger.info(f"WebSocket connection established for user {user_id} (connection_id: {connection_id})")
            
        except WebSocketDisconnect:
            # Registra falha no circuit breaker se o serviço de resiliência estiver disponível
            if resilience_service:
                resilience_service.record_failure(user_id)
            
            # Desconecta o WebSocket
            self.disconnect(websocket)
            
            logger.warning(f"WebSocket connection disconnected during setup for user {user_id}")
            
        except Exception as e:
            # Registra falha no circuit breaker se o serviço de resiliência estiver disponível
            if resilience_service:
                resilience_service.record_failure(user_id)
            
            # Desconecta o WebSocket
            if websocket.client_state.CONNECTED:
                await websocket.close(code=1011, reason=f"Error: {str(e)}")
            self.disconnect(websocket)
            
            logger.error(f"Error establishing WebSocket connection for user {user_id}: {str(e)}")
    
    def disconnect(self, websocket: WebSocket):
        """
        Desconecta um cliente WebSocket.
        
        Args:
            websocket: Conexão WebSocket
        """
        # Obtém metadados da conexão
        metadata = self.connection_metadata.get(websocket)
        if not metadata:
            return
        
        user_id = metadata["user_id"]
        connection_id = metadata.get("connection_id")
        subscribed_channels = metadata.get("subscribed_channels", [])
        
        # Remove das listas de conexões por canal
        for channel in subscribed_channels:
            if channel in self.active_connections and websocket in self.active_connections[channel]:
                self.active_connections[channel].discard(websocket)
                
                # Se não houver mais conexões para este canal, remove a entrada
                if not self.active_connections[channel]:
                    self.active_connections.pop(channel)
                    
                    # Cancela a tarefa de assinatura PubSub
                    if channel in self.pubsub_tasks:
                        self.pubsub_tasks[channel].cancel()
                        self.pubsub_tasks.pop(channel)
        
        # Remove da lista de conexões do usuário
        if user_id in self.user_connections:
            self.user_connections[user_id].discard(websocket)
            
            # Se não houver mais conexões para este usuário, remove a entrada
            if not self.user_connections[user_id]:
                self.user_connections.pop(user_id)
        
        # Cancela tarefa de heartbeat
        if websocket in self.heartbeat_tasks:
            self.heartbeat_tasks[websocket].cancel()
            self.heartbeat_tasks.pop(websocket)
        
        # Atualiza o repositório
        if self.repository and connection_id:
            asyncio.create_task(
                self.repository.update_connection(
                    connection_id,
                    {"status": WebSocketConnectionStatus.DISCONNECTED}
                )
            )
        
        # Remove metadados da conexão
        if websocket in self.connection_metadata:
            self.connection_metadata.pop(websocket)
        
        # Remove mapeamento de WebSocket para connection_id
        if websocket in self.websocket_to_connection_id:
            self.websocket_to_connection_id.pop(websocket)
        
        logger.info(f"WebSocket connection closed for user {user_id} (connection_id: {connection_id})")
    
    async def subscribe(self, websocket: WebSocket, channel: str):
        """
        Inscreve um cliente em um canal.
        
        Args:
            websocket: Conexão WebSocket
            channel: Nome do canal
        """
        # Adiciona o canal à lista de canais inscritos
        if websocket in self.connection_metadata:
            if "subscribed_channels" not in self.connection_metadata[websocket]:
                self.connection_metadata[websocket]["subscribed_channels"] = []
            
            # Verifica se já está inscrito
            if channel in self.connection_metadata[websocket]["subscribed_channels"]:
                return
            
            self.connection_metadata[websocket]["subscribed_channels"].append(channel)
            
            # Atualiza o repositório
            if self.repository and websocket in self.websocket_to_connection_id:
                connection_id = self.websocket_to_connection_id[websocket]
                await self.repository.update_connection(
                    connection_id,
                    {"subscribed_channels": self.connection_metadata[websocket]["subscribed_channels"]}
                )
        
        # Adiciona a conexão à lista de conexões do canal
        if channel not in self.active_connections:
            self.active_connections[channel] = set()
            
            # Se temos Redis, inscreve no canal PubSub
            if self.redis and channel not in self.pubsub_tasks:
                self.pubsub_tasks[channel] = asyncio.create_task(
                    self._subscribe_to_redis_channel(channel)
                )
        
        self.active_connections[channel].add(websocket)
        
        # Registra a atividade
        if self.repository and websocket in self.websocket_to_connection_id:
            connection_id = self.websocket_to_connection_id[websocket]
            await self.repository.log_message({
                "connection_id": connection_id,
                "event": "subscribe",
                "channel": channel,
                "timestamp": datetime.now().isoformat()
            })
        
        logger.info(f"WebSocket subscribed to channel {channel}")
    
    async def unsubscribe(self, websocket: WebSocket, channel: str):
        """
        Cancela a inscrição de um cliente em um canal.
        
        Args:
            websocket: Conexão WebSocket
            channel: Nome do canal
        """
        # Remove o canal da lista de canais inscritos
        if websocket in self.connection_metadata and "subscribed_channels" in self.connection_metadata[websocket]:
            if channel in self.connection_metadata[websocket]["subscribed_channels"]:
                self.connection_metadata[websocket]["subscribed_channels"].remove(channel)
                
                # Atualiza o repositório
                if self.repository and websocket in self.websocket_to_connection_id:
                    connection_id = self.websocket_to_connection_id[websocket]
                    await self.repository.update_connection(
                        connection_id,
                        {"subscribed_channels": self.connection_metadata[websocket]["subscribed_channels"]}
                    )
        
        # Remove a conexão da lista de conexões do canal
        if channel in self.active_connections:
            self.active_connections[channel].discard(websocket)
            
            # Se não houver mais conexões para este canal, remove a entrada
            if not self.active_connections[channel]:
                self.active_connections.pop(channel)
                
                # Se temos Redis, cancela a inscrição no canal PubSub
                if self.redis and channel in self.pubsub_tasks:
                    self.pubsub_tasks[channel].cancel()
                    self.pubsub_tasks.pop(channel)
        
        # Registra a atividade
        if self.repository and websocket in self.websocket_to_connection_id:
            connection_id = self.websocket_to_connection_id[websocket]
            await self.repository.log_message({
                "connection_id": connection_id,
                "event": "unsubscribe",
                "channel": channel,
                "timestamp": datetime.now().isoformat()
            })
        
        logger.info(f"WebSocket unsubscribed from channel {channel}")
    
    async def send_personal_message(
        self,
        user_id: str,
        message: Dict[str, Any],
        resilience_service = None
    ):
        """
        Envia uma mensagem para um usuário específico.
        
        Args:
            user_id: ID do usuário
            message: Mensagem a ser enviada
            resilience_service: Serviço de resiliência (opcional)
        """
        # Adiciona timestamp à mensagem
        if "timestamp" not in message:
            message["timestamp"] = datetime.now().isoformat()
        
        # Se o usuário não está conectado
        if user_id not in self.user_connections:
            # Armazena a mensagem no buffer se o serviço de resiliência estiver disponível
            if resilience_service:
                await resilience_service.buffer_message(user_id, message)
                logger.debug(f"Message buffered for offline user {user_id}")
            
            # Publica a mensagem no Redis
            if self.redis:
                channel = f"{self.user_channel_prefix}{user_id}"
                await self.redis.publish(channel, json.dumps(message))
            
            return
        
        # Converte a mensagem para JSON
        json_message = json.dumps(message)
        
        # Lista para armazenar conexões com erro
        disconnected_websockets = set()
        
        # Verifica se o circuit breaker permite enviar mensagens
        circuit_allowed = True
        if resilience_service:
            circuit_allowed = resilience_service.is_circuit_allowed(user_id)
        
        if not circuit_allowed:
            # Armazena a mensagem no buffer
            if resilience_service:
                await resilience_service.buffer_message
(Content truncated due to size limit. Use line ranges to read in chunks)