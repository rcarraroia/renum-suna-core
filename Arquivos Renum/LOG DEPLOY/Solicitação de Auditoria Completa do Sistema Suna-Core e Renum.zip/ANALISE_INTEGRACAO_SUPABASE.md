
## Análise da Integração com Supabase

A integração com Supabase é um componente central do sistema Suna-Core e Renum, servindo como banco de dados principal, sistema de autenticação e armazenamento de arquivos. A análise revela uma arquitetura complexa e bem estruturada, mas com algumas inconsistências e pontos de melhoria.

### Configuração e Credenciais

**Credenciais Fornecidas:**
- **URL**: `https://uxxvoicxhkakpguvavba.supabase.co`
- **Chave Anônima**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` (chave válida para operações do lado do cliente)

### Estrutura de Clientes Supabase

#### Backend (Sistema Suna) - `backend/services/supabase.py`

*   **Padrão Singleton**: Implementa um singleton thread-safe para gerenciar a conexão com Supabase.
*   **Cliente Assíncrono**: Utiliza `create_async_client` para operações não bloqueantes.
*   **Hierarquia de Chaves**: Prioriza `SUPABASE_SERVICE_ROLE_KEY` sobre `SUPABASE_ANON_KEY` para operações de backend, demonstrando boa prática de segurança.
*   **Tratamento de Erros**: Implementa tratamento robusto de erros com logging detalhado.
*   **Inicialização Lazy**: A conexão é inicializada apenas quando necessária.

#### Renum-Backend - `renum-backend/app/core/supabase_client.py`

*   **Duplo Cliente**: Mantém dois clientes separados - um com chave anônima e outro com chave de serviço.
*   **Padrão Singleton**: Implementa singleton para evitar múltiplas instâncias.
*   **Retry Logic**: Implementa decorador `@retry` para operações resilientes.
*   **Métodos CRUD**: Fornece métodos abstratos para operações CRUD (`create`, `read`, `update`, `delete`).
*   **Flexibilidade de Cliente**: Permite escolher entre cliente normal e admin via parâmetro `use_admin`.

#### Frontend e Admin

*   **Configuração Consistente**: Ambos utilizam as mesmas variáveis de ambiente (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`).
*   **Cliente Direto**: Utilizam `createClient` diretamente do SDK do Supabase.
*   **Autenticação Integrada**: Integração com Supabase Auth para gerenciamento de sessões.

### Estrutura do Banco de Dados

A análise das migrações revela uma arquitetura de banco de dados complexa e evolutiva:

#### Basejump Framework

O sistema utiliza o framework Basejump para gerenciamento de contas e billing:
*   **`basejump.accounts`**: Tabela principal de contas/organizações.
*   **Billing**: Sistema completo de cobrança e assinaturas.
*   **Invitations**: Sistema de convites para membros de equipe.
*   **RLS Integration**: Integração com Row Level Security do Supabase.

#### Schema Principal (AgentPress)

**Tabelas Principais:**
*   **`projects`**: Projetos de agentes com sandbox JSONB.
*   **`threads`**: Conversas/threads de chat.
*   **`messages`**: Mensagens individuais com conteúdo JSONB.
*   **`agent_runs`**: Execuções de agentes com status e metadados.

#### Sistema de Agentes

**Evolução Temporal das Migrações:**
*   **Versioning**: Sistema de versionamento de agentes (`20250525000000_agent_versioning.sql`).
*   **Marketplace**: Marketplace de agentes (`20250529125628_agent_marketplace.sql`).
*   **Workflows**: Sistema de workflows (`20250705161610_agent_workflows.sql`).
*   **Knowledge Base**: Integração com bases de conhecimento (`20250701082739_agent_knowledge_base.sql`).

#### Sistema Administrativo

**Tabelas de Administração:**
*   **`renum_admins`**: Administradores do sistema com roles (admin/superadmin).
*   **`renum_admin_credentials`**: Credenciais administrativas criptografadas.
*   **`renum_system_settings`**: Configurações do sistema.
*   **`renum_audit_logs`**: Logs de auditoria para rastreamento de ações.

### Row Level Security (RLS)

#### Implementação Robusta

**Políticas Baseadas em Basejump:**
```sql
-- Exemplo de política RLS
CREATE POLICY "Account members can view their own devices"
    ON public.devices FOR SELECT
    USING (basejump.has_role_on_account(account_id));
```

**Características:**
*   **Função `basejump.has_role_on_account()`**: Verifica se o usuário tem acesso à conta.
*   **Políticas Granulares**: Diferentes políticas para SELECT, INSERT, UPDATE, DELETE.
*   **Hierarquia de Permissões**: Superadmin pode acessar dados de admin.

#### Políticas Administrativas

**Controle de Acesso Hierárquico:**
```sql
CREATE POLICY admin_superadmin_policy ON renum_admins
    USING (
        (SELECT role FROM renum_admins WHERE user_id = auth.uid()) = 'superadmin'
        OR user_id = auth.uid()
    );
```

### Storage (Armazenamento de Arquivos)

#### Buckets Configurados

*   **`ui_grounding`**: Armazenamento de dados de interface.
*   **`ui_grounding_trajs`**: Trajetórias de interface.
*   **`recordings`**: Gravações com políticas RLS baseadas em conta.

#### Políticas de Storage

**Segurança por Conta:**
```sql
CREATE POLICY "Account members can select recording files"
    ON storage.objects FOR SELECT
    TO authenticated
    USING (
        bucket_id = 'recordings' AND
        (storage.foldername(name))[1]::uuid IN (SELECT basejump.get_accounts_with_role())
    );
```

### Pontos Fortes da Integração

1.  **Arquitetura Multi-Tenant**: Uso eficiente do Basejump para multi-tenancy.
2.  **Segurança Robusta**: RLS bem implementado com políticas granulares.
3.  **Evolução Controlada**: Migrações bem organizadas e versionadas.
4.  **Separação de Responsabilidades**: Diferentes clientes para diferentes contextos (frontend, backend, admin).
5.  **Auditoria**: Sistema de logs de auditoria para rastreamento de ações.
6.  **Resiliência**: Retry logic e tratamento de erros robusto.

### Pontos de Melhoria e Inconsistências

#### 1. Inconsistências de Nomenclatura

**Problema**: Mistura de convenções de nomenclatura:
*   Algumas tabelas usam prefixo `renum_` (e.g., `renum_admins`)
*   Outras não usam prefixo (e.g., `projects`, `threads`)
*   Migração `migration_script_complete.sql` tenta corrigir isso, mas pode não ter sido aplicada

**Impacto**: Confusão na manutenção e possíveis conflitos de nomes.

#### 2. Evolução Complexa do Schema

**Problema**: Múltiplas migrações para o mesmo conceito:
*   Workflows foram implementados, removidos (`20250705155923_rollback_workflows.sql`) e reimplementados
*   Múltiplas migrações para agent workflows indicam instabilidade no design

**Impacto**: Complexidade desnecessária e possível inconsistência de dados.

#### 3. Configuração de Chaves

**Problema**: Diferentes abordagens para chaves de serviço:
*   Backend Suna: `SUPABASE_SERVICE_ROLE_KEY` ou `SUPABASE_ANON_KEY`
*   Renum-Backend: `SUPABASE_SERVICE_KEY` (nome diferente)

**Impacto**: Possível confusão na configuração e falhas de autenticação.

#### 4. Falta de Validação de Schema

**Problema**: Não há evidência de validação de schema ou constraints adequados para campos JSONB.

**Impacto**: Possível inconsistência de dados e dificuldade de manutenção.

### Recomendações Críticas

#### 1. Padronização de Nomenclatura

```sql
-- Aplicar migração para padronizar nomes de tabelas
-- Usar prefixo consistente (renum_ ou agentpress_)
```

#### 2. Consolidação de Configurações

```bash
# Padronizar nomes de variáveis de ambiente
SUPABASE_URL=...
SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...  # Nome consistente
```

#### 3. Validação de Schema JSONB

```sql
-- Adicionar constraints para campos JSONB críticos
ALTER TABLE projects ADD CONSTRAINT valid_sandbox_schema 
CHECK (jsonb_typeof(sandbox) = 'object');
```

#### 4. Monitoramento de RLS

```sql
-- Criar função para monitorar políticas RLS
CREATE OR REPLACE FUNCTION check_rls_policies()
RETURNS TABLE(table_name text, policy_count bigint);
```

#### 5. Backup e Recuperação

*   Implementar estratégia de backup automatizado
*   Testar procedimentos de recuperação
*   Documentar processo de disaster recovery

### Segurança e Compliance

#### Pontos Positivos

*   **RLS Habilitado**: Todas as tabelas sensíveis têm RLS ativado
*   **Auditoria**: Sistema de logs de auditoria implementado
*   **Criptografia**: Credenciais administrativas são criptografadas
*   **Separação de Privilégios**: Diferentes chaves para diferentes contextos

#### Pontos de Atenção

*   **Logs de Auditoria**: Verificar se todos os eventos críticos são logados
*   **Retenção de Dados**: Definir políticas de retenção para logs e dados sensíveis
*   **Acesso de Emergência**: Garantir que existe acesso de emergência em caso de falhas

### Performance e Escalabilidade

#### Índices

**Verificar se existem índices adequados para:**
*   Foreign keys (account_id, user_id, etc.)
*   Campos de busca frequente
*   Campos de ordenação

#### Otimizações

*   **Connection Pooling**: Verificar configuração de pool de conexões
*   **Query Performance**: Monitorar queries lentas
*   **Storage Optimization**: Otimizar políticas de storage para arquivos grandes

Esta análise revela que a integração com Supabase é robusta e bem arquitetada, mas precisa de padronização e consolidação para melhorar a manutenibilidade e reduzir a complexidade operacional.

