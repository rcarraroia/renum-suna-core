#!/usr/bin/env python3
"""
Script para realizar análise de performance dos serviços Renum e Suna.
Este script coleta métricas de uso de recursos, identifica gargalos de performance e sugere otimizações.
"""

import os
import sys
import json
import argparse
import paramiko
import getpass
import re
import time
from pathlib import Path
from datetime import datetime

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Analyze performance')
    parser.add_argument('--host', default='157.180.39.41', help='VPS hostname or IP address')
    parser.add_argument('--port', type=int, default=22, help='SSH port')
    parser.add_argument('--user', default='root', help='SSH username')
    parser.add_argument('--key-file', help='Path to SSH private key file')
    parser.add_argument('--output-dir', default='./output', help='Directory to save output files')
    parser.add_argument('--containers-file', help='Path to containers JSON file (optional)')
    parser.add_argument('--samples', type=int, default=3, help='Number of performance samples to collect')
    parser.add_argument('--interval', type=int, default=5, help='Interval between samples in seconds')
    return parser.parse_args()

def create_ssh_client(host, port, user, key_file=None):
    """Create an SSH client connection."""
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        if key_file:
            key_path = os.path.expanduser(key_file)
            if not os.path.exists(key_path):
                print(f"Error: Key file {key_path} does not exist.")
                sys.exit(1)
            
            try:
                key = paramiko.RSAKey.from_private_key_file(key_path)
                client.connect(host, port=port, username=user, pkey=key)
            except paramiko.ssh_exception.PasswordRequiredException:
                passphrase = getpass.getpass("Enter passphrase for key: ")
                key = paramiko.RSAKey.from_private_key_file(key_path, password=passphrase)
                client.connect(host, port=port, username=user, pkey=key)
        else:
            password = getpass.getpass(f"Enter password for {user}@{host}: ")
            client.connect(host, port=port, username=user, password=password)
        
        return client
    except Exception as e:
        print(f"Error connecting to {host}: {str(e)}")
        sys.exit(1)

def execute_command(client, command):
    """Execute a command on the remote server."""
    try:
        stdin, stdout, stderr = client.exec_command(command)
        output = stdout.read().decode('utf-8')
        error = stderr.read().decode('utf-8')
        
        if error and not output:
            print(f"Error executing command: {error}")
        
        return output
    except Exception as e:
        print(f"Error executing command: {str(e)}")
        return None

def get_docker_containers(client):
    """Get list of Docker containers."""
    output = execute_command(client, "docker ps -a --format '{{.ID}},{{.Names}},{{.Status}},{{.Image}},{{.Ports}}'")
    containers = []
    
    if output:
        for line in output.strip().split('\n'):
            if line:
                parts = line.split(',', 4)
                if len(parts) >= 5:
                    container_id, name, status, image, ports = parts
                    containers.append({
                        'id': container_id,
                        'name': name,
                        'status': status,
                        'image': image,
                        'ports': ports,
                        'is_running': 'Up' in status
                    })
    
    # Categorize containers
    for container in containers:
        if 'renum' in container['name'].lower() or 'renum' in container['image'].lower():
            container['category'] = 'renum'
        elif 'suna' in container['name'].lower() or 'suna' in container['image'].lower():
            container['category'] = 'suna'
        elif 'postgres' in container['name'].lower() or 'postgres' in container['image'].lower():
            container['category'] = 'database'
        elif 'redis' in container['name'].lower() or 'redis' in container['image'].lower():
            container['category'] = 'cache'
        elif 'rabbitmq' in container['name'].lower() or 'rabbitmq' in container['image'].lower():
            container['category'] = 'message_queue'
        else:
            container['category'] = 'other'
    
    return containers

def get_system_resources(client):
    """Get system resources information."""
    # Get CPU info
    cpu_info = execute_command(client, "lscpu")
    
    # Get memory info
    memory_info = execute_command(client, "free -m")
    
    # Get disk usage
    disk_usage = execute_command(client, "df -h")
    
    # Get system load
    system_load = execute_command(client, "uptime")
    
    # Parse CPU count
    cpu_count = 1
    if cpu_info:
        cpu_count_match = re.search(r'CPU\(s\):\s+(\d+)', cpu_info)
        if cpu_count_match:
            cpu_count = int(cpu_count_match.group(1))
    
    # Parse memory total
    memory_total = 0
    if memory_info:
        memory_match = re.search(r'Mem:\s+(\d+)', memory_info)
        if memory_match:
            memory_total = int(memory_match.group(1))
    
    return {
        'cpu_info': cpu_info,
        'cpu_count': cpu_count,
        'memory_info': memory_info,
        'memory_total_mb': memory_total,
        'disk_usage': disk_usage,
        'system_load': system_load
    }

def get_container_stats(client, container_id):
    """Get container stats."""
    output = execute_command(client, f"docker stats {container_id} --no-stream --format '{{{{.CPUPerc}}}},{{{{.MemUsage}}}},{{{{.MemPerc}}}},{{{{.NetIO}}}},{{{{.BlockIO}}}},{{{{.PIDs}}}}'")
    
    if output:
        parts = output.strip().split(',')
        if len(parts) >= 6:
            cpu_perc = parts[0].replace('%', '')
            mem_usage = parts[1]
            mem_perc = parts[2].replace('%', '')
            net_io = parts[3]
            block_io = parts[4]
            pids = parts[5]
            
            # Parse memory usage
            mem_used = 0
            mem_limit = 0
            mem_match = re.search(r'([\d.]+)([A-Za-z]+) / ([\d.]+)([A-Za-z]+)', mem_usage)
            if mem_match:
                mem_used_val = float(mem_match.group(1))
                mem_used_unit = mem_match.group(2)
                mem_limit_val = float(mem_match.group(3))
                mem_limit_unit = mem_match.group(4)
                
                # Convert to MB for comparison
                if mem_used_unit == 'GiB':
                    mem_used = mem_used_val * 1024
                elif mem_used_unit == 'MiB':
                    mem_used = mem_used_val
                
                if mem_limit_unit == 'GiB':
                    mem_limit = mem_limit_val * 1024
                elif mem_limit_unit == 'MiB':
                    mem_limit = mem_limit_val
            
            return {
                'cpu_percent': float(cpu_perc) if cpu_perc else 0,
                'memory_usage': mem_usage,
                'memory_percent': float(mem_perc) if mem_perc else 0,
                'memory_used_mb': mem_used,
                'memory_limit_mb': mem_limit,
                'network_io': net_io,
                'block_io': block_io,
                'pids': int(pids) if pids.isdigit() else 0
            }
    
    return {
        'cpu_percent': 0,
        'memory_usage': '0B / 0B',
        'memory_percent': 0,
        'memory_used_mb': 0,
        'memory_limit_mb': 0,
        'network_io': '0B / 0B',
        'block_io': '0B / 0B',
        'pids': 0
    }

def get_container_top_processes(client, container_id):
    """Get top processes in a container."""
    output = execute_command(client, f"docker exec {container_id} ps aux --sort=-%cpu | head -6")
    
    if output:
        lines = output.strip().split('\n')
        if len(lines) > 1:  # Skip header
            processes = []
            for line in lines[1:]:
                parts = line.split()
                if len(parts) >= 11:
                    processes.append({
                        'user': parts[0],
                        'pid': parts[1],
                        'cpu_percent': float(parts[2]),
                        'memory_percent': float(parts[3]),
                        'command': ' '.join(parts[10:])
                    })
            return processes
    
    return []

def get_api_response_times(client, container_id, container_name, category):
    """Get API response times for common endpoints."""
    # Get container IP
    container_ip = execute_command(client, f"docker inspect -f '{{{{.NetworkSettings.IPAddress}}}}' {container_id}")
    
    if not container_ip or not container_ip.strip():
        # Try to get IP from networks
        networks_output = execute_command(client, f"docker inspect -f '{{{{json .NetworkSettings.Networks}}}}' {container_id}")
        
        if networks_output:
            try:
                networks = json.loads(networks_output.strip().strip("'"))
                for network in networks.values():
                    if 'IPAddress' in network and network['IPAddress']:
                        container_ip = network['IPAddress']
                        break
            except:
                pass
    
    if not container_ip or not container_ip.strip():
        return []
    
    container_ip = container_ip.strip()
    
    # Define endpoints to test based on category
    if category == 'renum':
        endpoints = [
            {'path': '/', 'method': 'GET'},
            {'path': '/health', 'method': 'GET'},
            {'path': '/docs', 'method': 'GET'},
            {'path': '/api/v1', 'method': 'GET'}
        ]
    elif category == 'suna':
        endpoints = [
            {'path': '/', 'method': 'GET'},
            {'path': '/health', 'method': 'GET'},
            {'path': '/docs', 'method': 'GET'},
            {'path': '/api/agent/status', 'method': 'GET'}
        ]
    else:
        endpoints = [
            {'path': '/', 'method': 'GET'},
            {'path': '/health', 'method': 'GET'}
        ]
    
    # Test response times
    results = []
    
    for endpoint in endpoints:
        path = endpoint['path']
        method = endpoint['method']
        url = f"http://{container_ip}:8000{path}"
        
        # Use curl to measure response time
        command = f"docker exec {container_id} curl -s -o /dev/null -w '%{{time_total}}' -X {method} {url}"
        response_time = execute_command(client, command)
        
        if response_time and response_time.strip():
            try:
                time_seconds = float(response_time.strip())
                results.append({
                    'endpoint': path,
                    'method': method,
                    'response_time_seconds': time_seconds
                })
            except:
                pass
    
    return results

def collect_performance_samples(client, containers, system_resources, num_samples=3, interval=5):
    """Collect multiple performance samples."""
    samples = []
    
    for i in range(num_samples):
        print(f"Coletando amostra de performance {i+1}/{num_samples}...")
        
        sample = {
            'timestamp': datetime.now().isoformat(),
            'system': {
                'load': execute_command(client, "uptime").strip(),
                'memory': execute_command(client, "free -m").strip(),
                'disk_io': execute_command(client, "iostat -x 1 1").strip()
            },
            'containers': {}
        }
        
        # Collect stats for each container
        for container in containers:
            if container['is_running']:
                container_id = container['id']
                container_name = container['name']
                
                stats = get_container_stats(client, container_id)
                sample['containers'][container_name] = stats
        
        samples.append(sample)
        
        # Wait for next sample
        if i < num_samples - 1:
            time.sleep(interval)
    
    return samples

def analyze_performance(system_resources, performance_samples, container_processes, api_response_times):
    """Analyze performance data."""
    analysis = {
        'system': {
            'cpu_count': system_resources['cpu_count'],
            'memory_total_mb': system_resources['memory_total_mb'],
            'high_load': False,
            'memory_pressure': False,
            'disk_pressure': False,
            'issues': []
        },
        'containers': {},
        'api_performance': {},
        'bottlenecks': [],
        'status': 'OK'
    }
    
    # Check system load
    if system_resources.get('system_load'):
        load_match = re.search(r'load average: ([\d.]+), ([\d.]+), ([\d.]+)', system_resources['system_load'])
        if load_match:
            load_1min = float(load_match.group(1))
            load_5min = float(load_match.group(2))
            load_15min = float(load_match.group(3))
            
            # High load is when load average is higher than number of CPUs
            if load_5min > system_resources['cpu_count']:
                analysis['system']['high_load'] = True
                analysis['system']['issues'].append(f"Carga do sistema alta: {load_5min} (limite: {system_resources['cpu_count']})")
    
    # Check memory pressure
    if system_resources.get('memory_info'):
        mem_available_match = re.search(r'available\s+(\d+)', system_resources['memory_info'])
        if mem_available_match:
            mem_available = int(mem_available_match.group(1))
            mem_total = system_resources['memory_total_mb']
            
            # Memory pressure when less than 20% available
            if mem_available < (mem_total * 0.2):
                analysis['system']['memory_pressure'] = True
                analysis['system']['issues'].append(f"Pressão de memória: {mem_available}MB disponível de {mem_total}MB")
    
    # Check disk usage
    if system_resources.get('disk_usage'):
        for line in system_resources['disk_usage'].split('\n'):
            if line.startswith('/dev/') and '%' in line:
                parts = line.split()
                if len(parts) >= 5:
                    usage_percent = int(parts[4].replace('%', ''))
                    if usage_percent > 85:
                        analysis['system']['disk_pressure'] = True
                        analysis['system']['issues'].append(f"Uso de disco alto: {usage_percent}% em {parts[5]}")
    
    # Analyze container performance
    for container_name in performance_samples[0]['containers'].keys():
        container_stats = [sample['containers'][container_name] for sample in performance_samples]
        
        # Calculate averages
        avg_cpu = sum(stat['cpu_percent'] for stat in container_stats) / len(container_stats)
        avg_mem = sum(stat['memory_percent'] for stat in container_stats) / len(container_stats)
        avg_pids = sum(stat['pids'] for stat in container_stats) / len(container_stats)
        
        container_analysis = {
            'avg_cpu_percent': avg_cpu,
            'avg_memory_percent': avg_mem,
            'avg_pids': avg_pids,
            'high_cpu': avg_cpu > 80,
            'high_memory': avg_mem > 80,
            'issues': []
        }
        
        # Check for issues
        if container_analysis['high_cpu']:
            container_analysis['issues'].append(f"Uso de CPU alto: {avg_cpu:.1f}%")
        
        if container_analysis['high_memory']:
            container_analysis['issues'].append(f"Uso de memória alto: {avg_mem:.1f}%")
        
        # Add top processes if available
        if container_name in container_processes:
            container_analysis['top_processes'] = container_processes[container_name]
        
        analysis['containers'][container_name] = container_analysis
    
    # Analyze API response times
    for container_name, response_times in api_response_times.items():
        if response_times:
            slow_endpoints = []
            for endpoint in response_times:
                if endpoint['response_time_seconds'] > 1.0:  # More than 1 second is slow
      
(Content truncated due to size limit. Use line ranges to read in chunks)