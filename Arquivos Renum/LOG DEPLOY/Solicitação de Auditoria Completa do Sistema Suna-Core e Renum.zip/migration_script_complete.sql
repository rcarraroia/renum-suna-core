-- SCRIPT DE MIGRAÇÃO COMPLETA PARA O SISTEMA RENUM
-- Este script corrige as inconsistências de nomenclatura e cria todas as tabelas necessárias

-- Criar extensão uuid-ossp se ainda não existir
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ========================================
-- PARTE 1: RENOMEAR TABELAS DO MÓDULO RAG PARA USAR PREFIXO RENUM_
-- ========================================

-- Renomear tabelas do módulo RAG para seguir a convenção de nomenclatura
ALTER TABLE IF EXISTS knowledge_bases RENAME TO renum_knowledge_bases;
ALTER TABLE IF EXISTS knowledge_collections RENAME TO renum_knowledge_collections;
ALTER TABLE IF EXISTS documents RENAME TO renum_documents;
ALTER TABLE IF EXISTS document_chunks RENAME TO renum_document_chunks;
ALTER TABLE IF EXISTS document_versions RENAME TO renum_document_versions;
ALTER TABLE IF EXISTS document_usage_stats RENAME TO renum_document_usage_stats;
ALTER TABLE IF EXISTS retrieval_feedback RENAME TO renum_retrieval_feedback;
ALTER TABLE IF EXISTS processing_jobs RENAME TO renum_processing_jobs;
ALTER TABLE IF EXISTS client_plans RENAME TO renum_client_plans;

-- ========================================
-- PARTE 2: CRIAR TABELAS PRINCIPAIS DO SISTEMA RENUM
-- ========================================

-- Tabela de clientes
CREATE TABLE IF NOT EXISTS renum_clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    plan_type TEXT NOT NULL DEFAULT 'free',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    metadata JSONB DEFAULT '{}'::jsonb
);

-- Tabela de usuários (relacionados aos clientes)
CREATE TABLE IF NOT EXISTS renum_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    auth_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES renum_clients(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE(auth_user_id, client_id)
);

-- Tabela de agentes
CREATE TABLE IF NOT EXISTS renum_agents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL REFERENCES renum_clients(id) ON DELETE CASCADE,
    created_by UUID NOT NULL REFERENCES auth.users(id),
    name TEXT NOT NULL,
    description TEXT,
    system_prompt TEXT,
    model TEXT NOT NULL DEFAULT 'gpt-3.5-turbo',
    temperature FLOAT DEFAULT 0.7,
    max_tokens INTEGER DEFAULT 1000,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_public BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    metadata JSONB DEFAULT '{}'::jsonb
);

-- Tabela de threads (conversas)
CREATE TABLE IF NOT EXISTS renum_threads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL REFERENCES renum_clients(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    agent_id UUID REFERENCES renum_agents(id) ON DELETE SET NULL,
    title TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    metadata JSONB DEFAULT '{}'::jsonb
);

-- Tabela de mensagens
CREATE TABLE IF NOT EXISTS renum_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    thread_id UUID NOT NULL REFERENCES renum_threads(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content TEXT NOT NULL,
    tokens_used INTEGER DEFAULT 0,
    model_used TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    metadata JSONB DEFAULT '{}'::jsonb
);

-- ========================================
-- PARTE 3: CRIAR TABELAS DO PAINEL ADMINISTRATIVO
-- ========================================

-- Tabela de administradores
CREATE TABLE IF NOT EXISTS renum_admins (