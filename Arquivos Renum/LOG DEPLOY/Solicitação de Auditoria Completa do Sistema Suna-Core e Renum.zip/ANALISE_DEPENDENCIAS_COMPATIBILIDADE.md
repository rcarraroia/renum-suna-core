
## Análise de Dependências e Compatibilidade

A análise das dependências revela inconsistências significativas entre os diferentes componentes do sistema, que podem causar problemas de compatibilidade, bugs sutis e dificuldades de manutenção. O sistema utiliza uma mistura de tecnologias Python e Node.js com diferentes estratégias de gerenciamento de dependências.

### Inconsistências Críticas Identificadas

#### 1. Versões Divergentes de Bibliotecas Python

**Backend Suna vs Renum-Backend:**

| Biblioteca | Backend Suna | Renum-Backend | Diferença |
|------------|--------------|---------------|-----------|
| FastAPI | `0.115.12` (fixo) | `>=0.95.0` (range) | 20+ versões de diferença |
| Uvicorn | `0.27.1` (fixo) | `>=0.21.1` (range) | 6+ versões de diferença |
| Supabase | `2.17.0` (fixo) | `>=1.0.3` (range) | Major version diferente |
| PyJWT | `2.10.1` (fixo) | `>=2.6.0` (range) | 4+ versões de diferença |
| Redis | `5.2.1` (fixo) | `aioredis>=2.0.1` | Bibliotecas diferentes! |

**Problemas Identificados:**

1.  **Redis Libraries**: Backend Suna usa `redis==5.2.1` enquanto Renum-Backend usa `aioredis>=2.0.1`
    *   **Impacto**: APIs diferentes, possível incompatibilidade de código
    *   **Risco**: Falhas de conexão, métodos não encontrados

2.  **Supabase Major Version**: Diferença entre v1.x e v2.x
    *   **Impacto**: Breaking changes na API, métodos deprecados
    *   **Risco**: Falhas de autenticação, queries malformadas

3.  **FastAPI Version Gap**: 20+ versões de diferença
    *   **Impacto**: Recursos novos não disponíveis, possíveis bugs de segurança
    *   **Risco**: Incompatibilidade de middleware, validação

#### 2. Estratégias de Versionamento Inconsistentes

**Backend Suna (pyproject.toml):**
*   **Estratégia**: Versões fixas (`==`)
*   **Vantagem**: Builds reproduzíveis
*   **Desvantagem**: Atualizações manuais necessárias

**Renum-Backend (requirements.txt):**
*   **Estratégia**: Versões mínimas (`>=`)
*   **Vantagem**: Atualizações automáticas
*   **Desvantagem**: Possíveis breaking changes

#### 3. Python Version Compatibility

**Versões Python Utilizadas:**
*   **Backend Suna**: `python3.11-alpine` (Docker), `>=3.11` (pyproject.toml)
*   **Renum-Backend**: `python:3.11-slim` (Docker)
*   **Sistema**: Python 3.11.0rc1 (release candidate)

**Análise:**
*   **Consistência**: Ambos usam Python 3.11
*   **Problema**: Sistema usa release candidate (instável)
*   **Recomendação**: Usar versão estável (3.11.x final)

### Análise Frontend (Node.js)

#### Versões Next.js e React

**Renum-Frontend vs Renum-Admin:**

| Biblioteca | Renum-Frontend | Renum-Admin | Compatibilidade |
|------------|----------------|-------------|-----------------|
| Next.js | `^14.2.30` | `14.1.0` | ⚠️ Minor version diferente |
| React | `^18` | `^18` | ✅ Compatível |
| React-DOM | `^18` | `^18` | ✅ Compatível |
| @supabase/supabase-js | `^2.39.3` | `^2.39.3` | ✅ Idêntico |

**Análise:**
*   **Supabase**: Versões idênticas (boa prática)
*   **Next.js**: Pequena diferença de versão pode causar inconsistências
*   **React**: Versões compatíveis

#### Lock Files Analysis

**Arquivos de Lock Encontrados:**
*   `renum-suna-core/backend/uv.lock` (Python - UV package manager)
*   `renum-suna-core/renum-frontend/package-lock.json` (Node.js - NPM)
*   `renum-suna-core/Suna frontend/package-lock.json` (Node.js - NPM)

**Observação**: Renum-Admin não possui lock file, indicando possível inconsistência de build.

### Gerenciadores de Pacotes

#### Python Package Managers

**Backend Suna:**
*   **Gerenciador**: UV (moderno, rápido)
*   **Arquivo**: `pyproject.toml` + `uv.lock`
*   **Vantagens**: Builds rápidos, resolução de dependências moderna

**Renum-Backend:**
*   **Gerenciador**: pip (tradicional)
*   **Arquivo**: `requirements.txt`
*   **Desvantagens**: Resolução de dependências menos robusta

#### Node.js Package Managers

**Todos os frontends:**
*   **Gerenciador**: NPM (padrão)
*   **Arquivos**: `package.json` + `package-lock.json`

### Dependências de Segurança

#### Bibliotecas de Segurança Críticas

**Backend Suna:**
```toml
"cryptography>=41.0.0"
"pyjwt==2.10.1"
"sentry-sdk[fastapi]==2.29.1"
```

**Renum-Backend:**
```txt
pyjwt>=2.6.0
cryptography>=40.0.2
```

**Problemas:**
*   **Cryptography**: Versões diferentes (41.0.0 vs 40.0.2)
*   **PyJWT**: Gap de versões pode incluir patches de segurança

### Análise de Compatibilidade Docker

#### Base Images

**Inconsistências:**
*   **Backend Suna**: `ghcr.io/astral-sh/uv:python3.11-alpine`
*   **Renum-Backend**: `python:3.11-slim`
*   **Frontend**: `node:20-slim`

**Problemas:**
*   **Alpine vs Debian**: Diferentes libc (musl vs glibc)
*   **Package Managers**: Diferentes sistemas de pacotes (apk vs apt)
*   **Compatibilidade**: Possíveis problemas com bibliotecas nativas

### Dependências Conflitantes Específicas

#### 1. Redis Client Libraries

**Problema Crítico:**
```python
# Backend Suna
import redis.asyncio as redis

# Renum-Backend  
import aioredis
```

**Impacto:**
*   APIs completamente diferentes
*   Métodos incompatíveis
*   Possível falha de comunicação entre serviços

**Solução:**
```python
# Padronizar para redis (mais moderno)
# Backend Suna: redis==5.2.1 ✅
# Renum-Backend: redis>=5.0.0 (substituir aioredis)
```

#### 2. Supabase Client Versions

**Backend vs Frontend:**
*   **Backend**: `supabase==2.17.0` (Python)
*   **Frontend**: `@supabase/supabase-js==2.39.3` (JavaScript)

**Análise:**
*   Versões diferentes mas compatíveis (mesmo major version)
*   APIs similares entre Python e JavaScript clients

### Vulnerabilidades de Segurança

#### Dependências Desatualizadas

**Potenciais Vulnerabilidades:**
*   **FastAPI 0.95.0** (Renum-Backend): Versões antigas podem ter CVEs
*   **Cryptography 40.0.2** (Renum-Backend): Patches de segurança perdidos
*   **PyJWT 2.6.0** (Renum-Backend): Possíveis vulnerabilidades JWT

### Recomendações de Correção

#### 1. Padronização Imediata

**Criar arquivo central de dependências:**
```toml
# shared-dependencies.toml
[python-deps]
fastapi = "0.115.12"
uvicorn = "0.27.1"
redis = "5.2.1"  # Substituir aioredis
supabase = "2.17.0"
pyjwt = "2.10.1"
cryptography = "45.0.5"

[node-deps]
next = "14.2.30"
react = "18"
supabase-js = "2.39.3"
```

#### 2. Migração Redis

**Renum-Backend - Substituir aioredis:**
```python
# Antes
import aioredis

# Depois
import redis.asyncio as redis
```

#### 3. Atualização Supabase

**Renum-Backend - Atualizar para v2:**
```txt
# requirements.txt
supabase>=2.17.0  # Atualizar de 1.0.3
```

#### 4. Padronização Docker

**Base images consistentes:**
```dockerfile
# Todos os backends Python
FROM python:3.11-slim

# Todos os frontends Node.js
FROM node:20-slim
```

#### 5. Lock Files

**Garantir lock files em todos os projetos:**
*   Renum-Admin: Gerar `package-lock.json`
*   Renum-Backend: Migrar para `pyproject.toml` + lock file

### Plano de Migração

#### Fase 1: Correções Críticas (Imediato)

1.  **Substituir aioredis por redis** no Renum-Backend
2.  **Atualizar Supabase** para v2.x no Renum-Backend
3.  **Padronizar versões** de bibliotecas de segurança

#### Fase 2: Padronização (1-2 semanas)

1.  **Migrar Renum-Backend** para pyproject.toml
2.  **Padronizar base images** Docker
3.  **Criar arquivo central** de dependências

#### Fase 3: Otimização (1 mês)

1.  **Implementar dependabot** para atualizações automáticas
2.  **Configurar security scanning** para vulnerabilidades
3.  **Documentar processo** de atualização de dependências

### Ferramentas de Monitoramento

#### Dependency Scanning

**Recomendações:**
*   **Snyk**: Scanning de vulnerabilidades
*   **Dependabot**: Atualizações automáticas
*   **Safety** (Python): Verificação de vulnerabilidades
*   **npm audit** (Node.js): Auditoria de segurança

#### CI/CD Integration

**Pipeline de verificação:**
```yaml
# .github/workflows/dependency-check.yml
- name: Check Python dependencies
  run: safety check
  
- name: Check Node.js dependencies  
  run: npm audit

- name: Check for outdated packages
  run: pip list --outdated
```

### Conclusão

O sistema apresenta inconsistências significativas de dependências que podem causar:

1.  **Falhas de Runtime**: Especialmente com Redis (aioredis vs redis)
2.  **Vulnerabilidades de Segurança**: Versões desatualizadas
3.  **Dificuldades de Manutenção**: Diferentes estratégias de versionamento
4.  **Problemas de Deploy**: Incompatibilidades entre ambientes

**Prioridade Alta:**
*   Corrigir incompatibilidade Redis
*   Atualizar bibliotecas de segurança
*   Padronizar versões críticas

**Prioridade Média:**
*   Migrar para pyproject.toml
*   Padronizar base images
*   Implementar dependency scanning

A resolução dessas inconsistências é crucial para a estabilidade e segurança do sistema em produção.

